<?php

namespace App\Http\Controllers;

use App\Models\Marca;
use App\Models\Carro;
use App\Models\Cor;
use Illuminate\Http\Request;

class GraphController extends Controller {
    
   public function loadDataGraphs() {
    // Supondo que você já tenha carregado os carros
    $carros = Carro::with(['modelo', 'cor', 'estado'])->get();
    $data = [];
    $cont = 0;

    foreach ($carros as $vel) {
        $marcaNome = optional(Marca::find($vel->modelo->marca_id))->name; // Usando optional para evitar erros
        $modeloNome = $vel->modelo->name ?? 'Desconhecido'; // Valor padrão se não houver modelo
        $corNome = $vel->cor->name ?? 'Desconhecido'; // Valor padrão se não houver cor
        $estadoNome = $vel->estado->abreviatura ?? 'Desconhecido'; 

        $data[$cont]['marca'] = $marcaNome;
        $data[$cont]['modelo'] = $modeloNome;
        $data[$cont]['cor'] = $corNome;
        $data[$cont]['placa'] = $vel->placa;
        $data[$cont]['estado'] = $estadoNome; // Adiciona o estado aos dados


        $cont++;
    }

    // CALCULA TOTAL / MARCA
    $total_marcas = [['Marcas', 'Quantidade de Carros']];
    $cont = 1;

    foreach (array_count_values(array_filter(array_column($data, 'marca'))) as $key => $value) {
        $total_marcas[$cont] = [$key, $value];
        $cont++;
    }
    $total_marcas = json_encode($total_marcas);

    // CALCULA TOTAL / MODELO
    $total_modelos = [['Modelos', 'Quantidade de Carros']];
    $cont = 1;

    foreach (array_count_values(array_filter(array_column($data, 'modelo'))) as $key => $value) {
        $total_modelos[$cont] = [$key, $value];
        $cont++;
    }
    $total_modelos = json_encode($total_modelos);


    $total_cors = [['Cores', 'Quantidade de Carros']];
    $cont = 1;

    foreach (array_count_values(array_filter(array_column($data, 'cor'))) as $key => $value) {
        $total_cors[$cont] = [$key, $value];
        $cont++;
    }
    $total_cors = json_encode($total_cors);

    
    $total_estados = [['Estados', 'Quantidade de Carros']];
    $cont = 1;
    
    // Certifique-se de que está acessando o estado corretamente
    $estados = array_filter(array_column($data, 'estado')); // Verifique se 'estado' é a chave correta
    
    foreach (array_count_values($estados) as $key => $value) {
        $total_estados[$cont] = [$key, $value];
        $cont++;
    }
    $total_estados = json_encode($total_estados);
    

    // Retornar os totais como JSON, se necessário
    return view('welcome', compact(['data', 'total_marcas', 'total_modelos', 'total_cors', 'total_estados']));
}

}