@extends('templates.main')

@section('content')
    <h1 class="mt-4 text-center"></h1>
@endsection 